"""
CATIA批量参数化建模模块
读取采样结果，批量修改CATIA模型参数并导出

作者: 自动生成
日期: 2026-02-08
"""

from pycatia import catia
import pandas as pd
import os
import time
from datetime import datetime
import json
from typing import Dict, List, Tuple
import traceback


class CATIABatchModeler:
    """CATIA批量建模器"""
    
    def __init__(self, template_path: str, output_dir: str):
        """
        初始化
        
        参数:
            template_path: CATIA模板文件路径
            output_dir: 输出目录
        """
        self.template_path = template_path
        self.output_dir = output_dir
        
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        # CATIA参数名称映射（Python名 -> CATIA名）
        self.param_mapping = {
            '旋翼直径': '旋翼直径',
            '翼根弦长': '翼根弦长',
            '翼中弦长': '翼中弦长',
            '翼尖弦长': '翼尖弦长',
            '翼根扭转角': '翼根扭转角',
            '翼中扭转角': '翼中扭转角',
            '翼尖扭转角': '翼尖扭转角',
        }
        
        # 日志
        self.log_file = os.path.join(output_dir, 
                                     f'batch_log_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt')
        
        # 成功和失败计数
        self.success_count = 0
        self.fail_count = 0
        self.failed_cases = []
    
    def log(self, message: str, also_print: bool = True):
        """写入日志"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_msg = f"[{timestamp}] {message}"
        
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(log_msg + '\n')
        
        if also_print:
            print(log_msg)
    
    def modify_parameters(self, doc, params_dict: Dict[str, float]) -> bool:
        """
        修改CATIA文件参数
        
        参数:
            doc: CATIA文档对象
            params_dict: 参数字典
        
        返回:
            是否成功
        """
        try:
            # 获取对象
            if self.template_path.endswith('.CATPart'):
                obj = doc.part
            elif self.template_path.endswith('.CATProduct'):
                obj = doc.product
            else:
                raise ValueError("不支持的文件类型")
            
            parameters = obj.parameters
            
            # 修改每个参数
            for py_name, catia_name in self.param_mapping.items():
                if py_name in params_dict:
                    try:
                        param = parameters.item(catia_name)
                        new_value = params_dict[py_name]
                        param.value = new_value
                        self.log(f"  ✓ {catia_name} = {new_value:.2f}", False)
                    except Exception as e:
                        self.log(f"  ✗ 参数 {catia_name} 修改失败: {e}", False)
                        return False
            
            # 更新模型
            self.log("  更新模型...", False)
            obj.update()
            
            # 等待更新完成
            time.sleep(1)
            
            return True
            
        except Exception as e:
            self.log(f"  ✗ 修改参数时出错: {e}")
            traceback.print_exc()
            return False
    
    def export_step(self, doc, output_path: str) -> bool:
        """
        导出STEP文件
        
        参数:
            doc: CATIA文档
            output_path: 输出路径
        
        返回:
            是否成功
        """
        try:
            doc.export_data(output_path, "stp")
            
            # 验证文件是否存在
            if os.path.exists(output_path):
                file_size = os.path.getsize(output_path)
                self.log(f"  ✓ STEP已导出: {os.path.basename(output_path)} ({file_size/1024:.1f} KB)", False)
                return True
            else:
                self.log(f"  ✗ STEP文件未生成", False)
                return False
                
        except Exception as e:
            self.log(f"  ✗ 导出STEP失败: {e}")
            return False
    
    def process_single_case(self, case_id: int, params: Dict[str, float], 
                           save_catia: bool = False) -> Dict:
        """
        处理单个设计案例
        
        参数:
            case_id: 案例ID
            params: 参数字典
            save_catia: 是否保存CATIA文件
        
        返回:
            结果字典
        """
        result = {
            'case_id': case_id,
            'success': False,
            'error': None,
            'step_path': None,
            'catia_path': None
        }
        
        self.log(f"\n{'='*70}")
        self.log(f"处理案例 #{case_id}")
        self.log(f"{'='*70}")
        
        # 打印参数
        for key, value in params.items():
            self.log(f"  {key}: {value:.2f}", False)
        
        try:
            # 1. 打开CATIA和模板文件
            self.log("  打开CATIA模板...")
            caa = catia()
            documents = caa.documents
            doc = documents.open(self.template_path)
            
            # 2. 修改参数
            self.log("  修改参数...")
            if not self.modify_parameters(doc, params):
                raise Exception("参数修改失败")
            
            # 3. 生成文件名
            step_filename = f"xv15_case_{case_id:04d}.stp"
            step_path = os.path.join(self.output_dir, step_filename)
            
            # 4. 导出STEP
            self.log("  导出STEP...")
            if not self.export_step(doc, step_path):
                raise Exception("STEP导出失败")
            
            result['step_path'] = step_path
            
            # 5. 可选：保存CATIA文件
            if save_catia:
                catia_filename = f"xv15_case_{case_id:04d}.CATProduct"
                catia_path = os.path.join(self.output_dir, catia_filename)
                
                self.log(f"  保存CATIA文件...")
                doc.save_as(catia_path)
                result['catia_path'] = catia_path
            
            # 6. 关闭文档（不保存原模板）
            doc.close()
            
            result['success'] = True
            self.success_count += 1
            self.log(f"✓ 案例 #{case_id} 完成")
            
        except Exception as e:
            result['error'] = str(e)
            self.fail_count += 1
            self.failed_cases.append(case_id)
            self.log(f"✗ 案例 #{case_id} 失败: {e}")
            traceback.print_exc()
            
            # 尝试关闭可能打开的文档
            try:
                doc.close()
            except:
                pass
        
        return result
    
    def batch_process(self, df: pd.DataFrame, 
                     start_idx: int = 0,
                     end_idx: int = None,
                     save_catia: bool = False,
                     save_interval: int = 10) -> pd.DataFrame:
        """
        批量处理
        
        参数:
            df: 包含设计参数的DataFrame
            start_idx: 起始索引
            end_idx: 结束索引（None表示到最后）
            save_catia: 是否保存CATIA文件
            save_interval: 每隔多少个保存一次进度
        
        返回:
            结果DataFrame
        """
        if end_idx is None:
            end_idx = len(df)
        
        total = end_idx - start_idx
        
        self.log(f"\n{'='*70}")
        self.log(f"批量建模开始")
        self.log(f"{'='*70}")
        self.log(f"模板文件: {self.template_path}")
        self.log(f"输出目录: {self.output_dir}")
        self.log(f"处理范围: {start_idx} - {end_idx} (共{total}个)")
        self.log(f"保存CATIA: {save_catia}")
        
        results_list = []
        start_time = time.time()
        
        for i in range(start_idx, end_idx):
            case_id = i + 1  # 从1开始编号
            
            # 获取参数
            params = df.iloc[i].to_dict()
            
            # 处理单个案例
            result = self.process_single_case(case_id, params, save_catia)
            results_list.append(result)
            
            # 进度报告
            processed = i - start_idx + 1
            progress = processed / total * 100
            elapsed = time.time() - start_time
            eta = elapsed / processed * (total - processed)
            
            self.log(f"\n进度: {processed}/{total} ({progress:.1f}%) | "
                    f"成功: {self.success_count} | 失败: {self.fail_count} | "
                    f"已用时: {elapsed/60:.1f}分钟 | 预计剩余: {eta/60:.1f}分钟")
            
            # 定期保存中间结果
            if processed % save_interval == 0:
                temp_results = pd.DataFrame(results_list)
                temp_results.to_csv(
                    os.path.join(self.output_dir, 'temp_results.csv'),
                    index=False, encoding='utf-8-sig'
                )
                self.log("✓ 中间结果已保存")
        
        # 最终结果
        results_df = pd.DataFrame(results_list)
        
        self.log(f"\n{'='*70}")
        self.log(f"批量建模完成")
        self.log(f"{'='*70}")
        self.log(f"总数: {total}")
        self.log(f"成功: {self.success_count}")
        self.log(f"失败: {self.fail_count}")
        self.log(f"成功率: {self.success_count/total*100:.1f}%")
        self.log(f"总耗时: {(time.time()-start_time)/60:.1f}分钟")
        
        if self.failed_cases:
            self.log(f"\n失败案例ID: {self.failed_cases}")
        
        return results_df


def quick_batch_example(samples_file: str, template_file: str, 
                       output_dir: str, n_cases: int = 10):
    """
    快速批量处理示例
    
    参数:
        samples_file: 采样结果CSV文件
        template_file: CATIA模板文件
        output_dir: 输出目录
        n_cases: 处理数量（用于测试）
    """
    print("="*70)
    print("CATIA批量建模 - 快速示例")
    print("="*70)
    
    # 1. 读取采样数据
    print("\n读取采样数据...")
    df = pd.read_csv(samples_file, encoding='utf-8-sig')
    print(f"✓ 读取 {len(df)} 个设计方案")
    
    # 2. 选择前N个进行测试
    df_test = df.head(n_cases)
    print(f"✓ 选择前 {n_cases} 个进行测试")
    
    # 3. 创建批量建模器
    modeler = CATIABatchModeler(
        template_path=template_file,
        output_dir=output_dir
    )
    
    # 4. 批量处理
    results = modeler.batch_process(
        df=df_test,
        save_catia=False,  # 测试时不保存CATIA文件
        save_interval=5
    )
    
    # 5. 保存结果
    results_file = os.path.join(output_dir, 'batch_results.csv')
    results.to_csv(results_file, index=False, encoding='utf-8-sig')
    print(f"\n✓ 结果已保存: {results_file}")
    
    # 6. 显示摘要
    print(f"\n{'='*70}")
    print("处理摘要")
    print(f"{'='*70}")
    print(results[['case_id', 'success', 'step_path']].head(10))
    
    return results


# ============================================================================
# 主程序
# ============================================================================

if __name__ == "__main__":
    
    # 配置
    SAMPLES_FILE = "xv15_design_samples.csv"
    TEMPLATE_FILE = r"D:\17484\Documents\OneDrive\Desktop\XV-15桨叶总成\XV-15 ASM.CATProduct"
    OUTPUT_DIR = r"D:\17484\Documents\OneDrive\Desktop\XV-15_Batch_Output"
    
    # 检查文件
    if not os.path.exists(SAMPLES_FILE):
        print(f"错误: 采样文件不存在: {SAMPLES_FILE}")
        print("请先运行 xv15_sampling.py 生成采样数据")
        exit(1)
    
    if not os.path.exists(TEMPLATE_FILE):
        print(f"错误: 模板文件不存在: {TEMPLATE_FILE}")
        exit(1)
    
    # 快速测试（处理前10个）
    print("\n【模式1】快速测试（前10个）")
    choice = input("是否运行快速测试? (y/n): ")
    
    if choice.lower() == 'y':
        results = quick_batch_example(
            samples_file=SAMPLES_FILE,
            template_file=TEMPLATE_FILE,
            output_dir=OUTPUT_DIR,
            n_cases=10
        )
    
    # 完整批量处理
    print("\n【模式2】完整批量处理")
    choice = input("是否运行完整批量处理? (y/n): ")
    
    if choice.lower() == 'y':
        df = pd.read_csv(SAMPLES_FILE, encoding='utf-8-sig')
        
        n_total = len(df)
        print(f"\n将处理 {n_total} 个设计方案")
        print(f"预计耗时: {n_total * 0.5:.0f} 分钟 (按每个30秒估算)")
        
        confirm = input("\n确认开始? (yes/no): ")
        if confirm.lower() == 'yes':
            modeler = CATIABatchModeler(
                template_path=TEMPLATE_FILE,
                output_dir=OUTPUT_DIR
            )
            
            results = modeler.batch_process(
                df=df,
                save_catia=False,  # 不保存CATIA文件以节省空间
                save_interval=20
            )
            
            # 保存最终结果
            results.to_csv(
                os.path.join(OUTPUT_DIR, 'final_batch_results.csv'),
                index=False, encoding='utf-8-sig'
            )
            
            print("\n✅ 批量处理完成!")
        else:
            print("已取消")
