"""
XV-15螺旋桨BEM筛选和集成模块
从设计参数进行BEM分析，筛选高效率方案用于CFD

作者: 自动生成
日期: 2026-02-08  
"""

import numpy as np
import pandas as pd
import os
from typing import List, Dict, Tuple
import matplotlib.pyplot as plt
from tqdm import tqdm

# 导入BEM模块 (假设在同一目录)
try:
    from bem_propeller import (
        PropellerGeometry, FlowConditions, BEMSolver, AirfoilData
    )
except:
    print("警告: 无法导入bem_propeller模块,请确保文件在同一目录")

plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']  
plt.rcParams['axes.unicode_minus'] = False


class XV15GeometryExtractor:
    """从设计参数提取XV-15螺旋桨几何"""
    
    @staticmethod
    def extract_from_params(params: Dict[str, float], 
                           n_stations: int = 30) -> PropellerGeometry:
        """
        从设计参数生成螺旋桨几何分布
        
        参数:
            params: 设计参数字典
            n_stations: 径向站位数
        
        返回:
            PropellerGeometry对象
        """
        # 提取参数
        D = params.get('旋翼直径', 7620.0) / 1000.0  # 转换为米
        n_blades = int(params.get('桨叶数', 3))
        hub_ratio = 0.15  # XV-15轮毂比约15%
        
        # 三个截面参数  
        c_root = params.get('翼根弦长', 431.8) / 1000.0  # mm -> m
        c_mid = params.get('翼中弦长', 368.3) / 1000.0
        c_tip = params.get('翼尖弦长', 304.8) / 1000.0
        
        twist_root = params.get('翼根扭转角', 40.25)  # deg
        twist_mid = params.get('翼中扭转角', 18.25)
        twist_tip = params.get('翼尖扭转角', -3.75)
        
        # 创建径向分布
        R = D / 2
        r_hub = R * hub_ratio
        r_tip = R
        
        # 定义三个关键截面位置
        r_root = 0.25 * R  # 根部截面在25% R处
        r_mid = 0.625 * R  # 中部截面在62.5% R处（中间）
        
        # 创建站位
        radius = np.linspace(r_hub, r_tip, n_stations)
        
        # 插值弦长和扭转角分布
        chord = np.zeros(n_stations)
        twist = np.zeros(n_stations)
        
        for i, r in enumerate(radius):
            if r <= r_root:
                chord[i] = c_root
                twist[i] = twist_root
            elif r <= r_mid:
                t = (r - r_root) / (r_mid - r_root)
                chord[i] = c_root * (1 - t) + c_mid * t
                twist[i] = twist_root * (1 - t) + twist_mid * t
            else:
                t = (r - r_mid) / (r_tip - r_mid)
                chord[i] = c_mid * (1 - t) + c_tip * t
                twist[i] = twist_mid * (1 - t) + twist_tip * t
        
        # 估算螺距
        idx_75 = np.argmin(np.abs(radius / R - 0.75))
        beta_75 = twist[idx_75] * np.pi / 180
        pitch = 2 * np.pi * radius[idx_75] * np.tan(beta_75)
        
        return PropellerGeometry(
            D=D,
            n_blades=n_blades,
            hub_ratio=hub_ratio,
            pitch=pitch,
            chord=chord,
            twist=twist,
            radius=radius
        )


class XV15BEMScreener:
    """XV-15螺旋桨BEM筛选器"""
    
    def __init__(self, design_point: Dict[str, float] = None):
        """初始化"""
        # XV-15典型工况
        if design_point is None:
            design_point = {
                'V_inf': 77.2,  # 150 knots
                'rpm': 397,     # 飞机模式
            }
        
        self.design_point = design_point
        self.airfoil = AirfoilData("NACA 0012")
        self.results = []
    
    def analyze_single(self, case_id: int, params: Dict[str, float]) -> Dict:
        """分析单个设计"""
        result = {
            'case_id': case_id,
            'success': False,
            '翼根弦长': params.get('翼根弦长', np.nan),
            '翼中弦长': params.get('翼中弦长', np.nan),
            '翼尖弦长': params.get('翼尖弦长', np.nan),
            '翼根扭转角': params.get('翼根扭转角', np.nan),
            '翼中扭转角': params.get('翼中扭转角', np.nan),
            '翼尖扭转角': params.get('翼尖扭转角', np.nan),
        }
        
        try:
            # 提取几何
            geom = XV15GeometryExtractor.extract_from_params(params)
            
            # 创建流动条件
            flow = FlowConditions(
                V_inf=self.design_point['V_inf'],
                rpm=self.design_point['rpm']
            )
            
            # BEM求解
            solver = BEMSolver(geom, flow, airfoil=self.airfoil, 
                             n_iter=50, tol=1e-4)
            bem_result = solver.solve(verbose=False)
            
            # 提取结果
            result.update({
                'T_N': bem_result['T'],
                'P_kW': bem_result['P'] / 1000,
                'eta_%': bem_result['eta'] * 100,
                'CT': bem_result['CT'],
                'CP': bem_result['CP'],
                'J': bem_result['J'],
                'FOM': bem_result['eta'] * bem_result['CT'] / bem_result['CP'] 
                       if bem_result['CP'] > 0 else 0,
                'success': True
            })
            
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    def batch_analyze(self, df_designs: pd.DataFrame,
                     save_path: str = None) -> pd.DataFrame:
        """批量分析"""
        print(f"\nXV-15螺旋桨BEM批量分析")
        print(f"设计数量: {len(df_designs)}")
        
        results = []
        for i in tqdm(range(len(df_designs)), desc="BEM分析"):
            params = df_designs.iloc[i].to_dict()
            result = self.analyze_single(i + 1, params)
            results.append(result)
        
        df_results = pd.DataFrame(results)
        
        # 统计
        success_count = df_results['success'].sum()
        print(f"\n成功: {success_count}/{len(df_designs)}")
        
        if save_path:
            df_results.to_csv(save_path, index=False, encoding='utf-8-sig')
            print(f"结果已保存: {save_path}")
        
        return df_results
    
    def select_top_designs(self, df_results: pd.DataFrame,
                          n_select: int = 200) -> pd.DataFrame:
        """筛选优秀设计"""
        df_valid = df_results[df_results['success'] == True].copy()
        df_sorted = df_valid.sort_values('eta_%', ascending=False)
        df_selected = df_sorted.head(n_select)
        
        print(f"\n筛选Top {n_select}:")
        print(f"效率范围: {df_selected['eta_%'].min():.1f}% ~ "
              f"{df_selected['eta_%'].max():.1f}%")
        
        return df_selected


def complete_workflow(samples_file: str, output_dir: str, n_select: int = 200):
    """完整工作流"""
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. 读取采样数据
    df_designs = pd.read_csv(samples_file, encoding='utf-8-sig')
    print(f"读取 {len(df_designs)} 个设计方案")
    
    # 2. BEM分析
    screener = XV15BEMScreener()
    bem_file = os.path.join(output_dir, 'bem_results.csv')
    df_results = screener.batch_analyze(df_designs, save_path=bem_file)
    
    # 3. 筛选
    df_selected = screener.select_top_designs(df_results, n_select=n_select)
    selected_file = os.path.join(output_dir, f'top{n_select}.csv')
    df_selected.to_csv(selected_file, index=False, encoding='utf-8-sig')
    
    print(f"\n完成! 输出: {output_dir}")
    return df_results, df_selected


if __name__ == "__main__":
    complete_workflow('xv15_design_samples.csv', 'XV15_Screening', n_select=200)
